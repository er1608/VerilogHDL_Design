# CNN-FPGA
Implementation of CNN on ZYNQ FPGA to classify handwritten numbers using MNIST database

Network
Conv2D->Tanh Activation->AvgPool->Conv2D->Tanh Activation->AvgPool->Conv2D->Tanh Activation->Fully Connected Layer->Relu->Fully Connected Layer->Softmax

Further information regarding architecture and number of LUTS can be found in the Hardware Documentation
